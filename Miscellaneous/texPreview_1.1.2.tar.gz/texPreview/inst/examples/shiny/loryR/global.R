library(loryR)
library(texPreview)

outDir='www'
sapply(list.files(outDir,full.names = T),file.remove)

